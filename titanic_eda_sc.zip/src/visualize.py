
import os
import matplotlib.pyplot as plt
import pandas as pd

from .utils import ensure_dir, project_paths, log

def plot_age_distribution_by_survival(df: pd.DataFrame, fname: str = "idade_por_sobrevivencia.png") -> str:
    paths = project_paths()
    outdir = paths["outputs_figs"]
    ensure_dir(outdir)

    survived_col = "Survived"
    if survived_col not in df.columns:
        log("Coluna 'Survived' não encontrada; pulando gráfico de idade por sobrevivência")
        return ""

    plt.figure(figsize=(8, 5))
    # Filtrar idades válidas
    sub = df[["Age", survived_col]].dropna(subset=["Age"]).copy()
    # Histogramas sobrepostos
    for val, label, color in [(0, "Não sobreviveu", "#d62728"), (1, "Sobreviveu", "#2ca02c")]:
        if sub[survived_col].dtype.name == 'category':
            mask = sub[survived_col].astype(int) == val
        else:
            mask = sub[survived_col] == val
        plt.hist(sub.loc[mask, "Age"], bins=25, alpha=0.6, label=label, color=color)
    plt.title("Distribuição de Idade por Sobrevivência")
    plt.xlabel("Idade")
    plt.ylabel("Frequência")
    plt.legend()
    outpath = os.path.join(outdir, fname)
    plt.tight_layout()
    plt.savefig(outpath, dpi=150)
    plt.close()
    log(f"Gráfico salvo em {outpath}")
    return outpath

def plot_survival_rate_by(df: pd.DataFrame, by: str, fname: str) -> str:
    paths = project_paths()
    outdir = paths["outputs_figs"]
    ensure_dir(outdir)

    if "Survived" not in df.columns or by not in df.columns:
        log(f"Colunas necessárias ausentes para gráfico por '{by}'")
        return ""

    tmp = df.copy()
    if tmp["Survived"].dtype.name == 'category':
        tmp["Survived"] = tmp["Survived"].astype(int)
    rates = tmp.groupby(by)["Survived"].mean()

    plt.figure(figsize=(7, 4))
    rates.sort_values(ascending=False).plot(kind='bar', color="#1f77b4")
    plt.title(f"Taxa de sobrevivência por {by}")
    plt.ylabel("Taxa de sobrevivência")
    plt.xlabel(by)
    plt.ylim(0, 1)
    outpath = os.path.join(outdir, fname)
    plt.tight_layout()
    plt.savefig(outpath, dpi=150)
    plt.close()
    log(f"Gráfico salvo em {outpath}")
    return outpath
