
from typing import Tuple, Dict
import pandas as pd
import numpy as np

from .utils import log

# ------------------------------
# Importação e compreensão dos dados
# ------------------------------
def load_data(csv_path: str, sep: str = ",") -> pd.DataFrame:
    log(f"Carregando dados: {csv_path}")
    df = pd.read_csv(csv_path, sep=sep)
    return df

def basic_overview(df: pd.DataFrame) -> Dict[str, object]:
    info = {
        "shape": df.shape,
        "columns": df.columns.tolist(),
        "dtypes": df.dtypes.astype(str).to_dict(),
        "head": df.head(10).to_dict(orient="list"),
        "describe_numeric": df.select_dtypes(include=["number"]).describe().to_dict(),
    }
    return info

# ------------------------------
# Preparação e tratamento dos dados
# ------------------------------
def check_missing_and_duplicates(df: pd.DataFrame) -> Dict[str, object]:
    missing = df.isna().sum().to_dict()
    duplicates = int(df.duplicated().sum())
    return {"missing": missing, "duplicates": duplicates}

def drop_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    before = len(df)
    df = df.drop_duplicates().copy()
    after = len(df)
    log(f"Removidas {before - after} linhas duplicadas")
    return df

def adjust_dtypes(df: pd.DataFrame) -> pd.DataFrame:
    # Conversões típicas do Titanic
    conv = df.copy()
    for col in ["Survived", "Pclass"]:
        if col in conv.columns:
            conv[col] = conv[col].astype("Int64")
            conv[col] = conv[col].astype("category")
    for col in ["Sex", "Embarked"]:
        if col in conv.columns:
            conv[col] = conv[col].astype("category")
    for col in ["Age", "Fare"]:
        if col in conv.columns:
            conv[col] = pd.to_numeric(conv[col], errors="coerce")
    for col in ["Name", "Ticket", "Cabin"]:
        if col in conv.columns:
            conv[col] = conv[col].astype("string")
    return conv

def feature_engineering(df: pd.DataFrame) -> pd.DataFrame:
    fe = df.copy()
    # Tamanho da família
    if set(["SibSp", "Parch"]).issubset(fe.columns):
        fe["FamilySize"] = fe["SibSp"].fillna(0) + fe["Parch"].fillna(0) + 1
    # IsAlone
    if "FamilySize" in fe.columns:
        fe["IsAlone"] = (fe["FamilySize"] == 1).astype("int")
    # Título do passageiro, extraído do nome
    if "Name" in fe.columns:
        fe["Title"] = fe["Name"].fillna("").str.extract(r",\s*([^\.]+)\.", expand=False).fillna("Desconhecido")
        fe["Title"] = fe["Title"].astype("category")
    return fe

def impute_basic(df: pd.DataFrame) -> pd.DataFrame:
    im = df.copy()
    # Embarked: modo
    if "Embarked" in im.columns:
        mode_emb = im["Embarked"].mode(dropna=True)
        if len(mode_emb) > 0:
            im["Embarked"] = im["Embarked"].fillna(mode_emb.iloc[0])
    # Fare: mediana
    if "Fare" in im.columns:
        im["Fare"] = im["Fare"].fillna(im["Fare"].median())
    # Age: mediana por (Sex, Pclass)
    if set(["Age", "Sex", "Pclass"]).issubset(im.columns):
        im["Age"] = im.groupby(["Sex", "Pclass"])['Age'].transform(lambda s: s.fillna(s.median()))
    else:
        if "Age" in im.columns:
            im["Age"] = im["Age"].fillna(im["Age"].median())
    # Cabin: opcionalmente preencher ausente como 'Desconhecida'
    if "Cabin" in im.columns:
        im["Cabin"] = im["Cabin"].fillna("Desconhecida")
    return im

# ------------------------------
# Análises e métricas
# ------------------------------
def survival_rates(df: pd.DataFrame, by: str = None) -> pd.DataFrame:
    if "Survived" not in df.columns:
        raise ValueError("Coluna 'Survived' ausente no dataset.")
    surv = df.copy()
    # Converter Survived para numérico 0/1 se necessário
    if str(surv["Survived"].dtype) == "category":
        surv["Survived"] = surv["Survived"].astype("int")
    if by is None:
        rate = surv["Survived"].mean()
        return pd.DataFrame({"taxa_sobrevivencia": [rate]})
    else:
        return (surv.groupby(by)["Survived"].mean().reset_index().rename(columns={"Survived": "taxa_sobrevivencia"}))

def numeric_distributions(df: pd.DataFrame) -> pd.DataFrame:
    num = df.select_dtypes(include=["number"]).describe().T
    num["missing"] = df.select_dtypes(include=["number"]).isna().sum()
    return num

def category_counts(df: pd.DataFrame, cols=None) -> Dict[str, pd.DataFrame]:
    if cols is None:
        cols = df.select_dtypes(include=["category", "object", "string"]).columns.tolist()
    out = {}
    for c in cols:
        out[c] = df[c].value_counts(dropna=False).rename("contagem").to_frame()
    return out
