
import os
import sys
from typing import Optional

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

def project_paths(base_dir: Optional[str] = None) -> dict:
    base = base_dir or os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    return {
        "base": base,
        "data_raw": os.path.join(base, "data", "raw"),
        "data_processed": os.path.join(base, "data", "processed"),
        "outputs_figs": os.path.join(base, "outputs", "figs"),
        "reports": os.path.join(base, "reports"),
    }

def log(msg: str) -> None:
    print(f"[TITANIC-EDA] {msg}")

def find_csv_in_raw(filename_hint: str = "titanic") -> Optional[str]:
    paths = project_paths()
    raw = paths["data_raw"]
    if not os.path.isdir(raw):
        return None
    candidates = []
    for fn in os.listdir(raw):
        if fn.lower().endswith(".csv") and filename_hint.lower() in fn.lower():
            candidates.append(os.path.join(raw, fn))
    if candidates:
        # Choose the first by name order for determinism
        return sorted(candidates)[0]
    # Fallback: any CSV
    for fn in os.listdir(raw):
        if fn.lower().endswith(".csv"):
            return os.path.join(raw, fn)
    return None

def download_titanic_from_drive(file_id: str, output_path: str) -> bool:
    """
    Tenta baixar o CSV do Google Drive usando gdown.
    Retorna True se conseguir, False caso contrário.
    """
    try:
        import gdown  # type: ignore
        url = f"https://drive.google.com/uc?id={file_id}"
        log(f"Baixando dataset do Google Drive para {output_path} ...")
        gdown.download(url, output_path, quiet=False)
        return os.path.exists(output_path)
    except Exception as e:
        log(f"Aviso: não foi possível baixar automaticamente: {e}")
        return False
