
from typing import Dict, Callable
import pandas as pd

from .eda_titanic import (
    drop_duplicates,
    adjust_dtypes,
    feature_engineering,
    impute_basic,
)

# Definição de "regras" para cada cenário de preparação de dados
# Cada cenário recebe um DataFrame e retorna um DataFrame transformado

def cenario_1_basico(df: pd.DataFrame) -> pd.DataFrame:
    """Cenário 1: limpeza mínima (remover duplicados, ajustar tipos, features básicas)."""
    df1 = drop_duplicates(df)
    df1 = adjust_dtypes(df1)
    df1 = feature_engineering(df1)
    return df1

def cenario_2_imputacao(df: pd.DataFrame) -> pd.DataFrame:
    """Cenário 2: inclui imputação (mediana/moda) além do básico."""
    df2 = cenario_1_basico(df)
    df2 = impute_basic(df2)
    return df2

def cenario_3_drop_ausentes(df: pd.DataFrame) -> pd.DataFrame:
    """Cenário 3: excluir linhas com ausentes em colunas-chave, além do básico."""
    df3 = cenario_1_basico(df)
    key_cols = [c for c in ["Age", "Embarked", "Fare"] if c in df3.columns]
    if key_cols:
        df3 = df3.dropna(subset=key_cols)
    return df3

SCENARIOS: Dict[str, Callable[[pd.DataFrame], pd.DataFrame]] = {
    "basico": cenario_1_basico,
    "imputacao": cenario_2_imputacao,
    "drop_ausentes": cenario_3_drop_ausentes,
}
