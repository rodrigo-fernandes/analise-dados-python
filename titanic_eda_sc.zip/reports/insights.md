# Insights da Análise Exploratória do Titanic

(Execute `python main.py` para gerar o relatório completo.)
