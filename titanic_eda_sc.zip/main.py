
import argparse
import os
from datetime import datetime

import pandas as pd

from src.utils import project_paths, ensure_dir, log, find_csv_in_raw, download_titanic_from_drive
from src.eda_titanic import load_data, basic_overview, check_missing_and_duplicates, survival_rates, numeric_distributions, category_counts
from src.scenarios import SCENARIOS
from src.visualize import plot_age_distribution_by_survival, plot_survival_rate_by

GOOGLE_DRIVE_FILE_ID = "11HptTxJbUMRG16xpC39fcliba_-Z_J9d"

def run_all(csv_path: str | None, scenario_keys: list[str]) -> None:
    paths = project_paths()
    ensure_dir(paths["reports"]) 
    ensure_dir(paths["data_processed"]) 

    # Resolver CSV: usar caminho fornecido, tentar localizar na pasta raw ou baixar
    resolved_csv = None
    if csv_path and os.path.exists(csv_path):
        resolved_csv = csv_path
    else:
        resolved_csv = find_csv_in_raw()
        if not resolved_csv:
            out_csv = os.path.join(paths["data_raw"], "titanic.csv")
            ensure_dir(paths["data_raw"]) 
            ok = download_titanic_from_drive(GOOGLE_DRIVE_FILE_ID, out_csv)
            if ok:
                resolved_csv = out_csv
    if not resolved_csv:
        log("Erro: dataset Titanic não encontrado. Coloque o CSV em data/raw e tente novamente.")
        return

    # Importação
    df = load_data(resolved_csv)

    # Informações gerais
    overview = basic_overview(df)
    qc = check_missing_and_duplicates(df)

    # Relatório inicial
    insights_path = os.path.join(paths["reports"], "insights.md")
    with open(insights_path, "w", encoding="utf-8") as rep:
        rep.write(f"# Insights da Análise Exploratória do Titanic\n\n")
        rep.write(f"_Gerado em: {datetime.now():%Y-%m-%d %H:%M}_\n\n")
        rep.write("## 1. Compreensão inicial\n\n")
        rep.write(f"**Formato**: {overview['shape']}\n\n")
        rep.write("**Colunas e tipos**:\n\n")
        for c, t in overview["dtypes"].items():
            rep.write(f"- {c}: {t}\n")
        rep.write("\n**Valores ausentes (por coluna)**:\n\n")
        for c, m in qc["missing"].items():
            rep.write(f"- {c}: {m}\n")
        rep.write(f"\n**Linhas duplicadas**: {qc['duplicates']}\n\n")

    # Executar cenários
    for key in scenario_keys:
        if key not in SCENARIOS:
            log(f"Cenário '{key}' desconhecido; pulando.")
            continue
        log(f"Executando cenário: {key}")
        transform = SCENARIOS[key]
        dfx = transform(df)

        # Exportar dataset processado
        out_csv = os.path.join(paths["data_processed"], f"titanic_{key}.csv")
        dfx.to_csv(out_csv, index=False)

        # Métricas de sobrevivência
        overall = survival_rates(dfx)
        by_sex = survival_rates(dfx, by="Sex") if "Sex" in dfx.columns else None
        by_pclass = survival_rates(dfx, by="Pclass") if "Pclass" in dfx.columns else None
        by_embarked = survival_rates(dfx, by="Embarked") if "Embarked" in dfx.columns else None

        # Visualizações
        plot_age_distribution_by_survival(dfx, fname=f"idade_por_sobrevivencia_{key}.png")
        if "Sex" in dfx.columns:
            plot_survival_rate_by(dfx, by="Sex", fname=f"taxa_sobrevivencia_por_sexo_{key}.png")
        if "Pclass" in dfx.columns:
            plot_survival_rate_by(dfx, by="Pclass", fname=f"taxa_sobrevivencia_por_classe_{key}.png")

        # Atualizar relatório
        with open(insights_path, "a", encoding="utf-8") as rep:
            rep.write(f"\n---\n\n## 2. Cenário: {key}\n\n")
            rep.write("**Regra aplicada**: ")
            if key == "basico":
                rep.write("Remoção de duplicados, ajuste de tipos e criação de variáveis derivadas.\n\n")
            elif key == "imputacao":
                rep.write("Cenário básico + imputação por mediana/moda e preenchimento de cabine como 'Desconhecida'.\n\n")
            elif key == "drop_ausentes":
                rep.write("Cenário básico + exclusão de linhas com ausentes em (Age, Embarked, Fare).\n\n")

            rep.write("**Taxa de sobrevivência (geral)**:\n\n")
            rep.write(overall.to_markdown(index=False) + "\n\n")

            if by_sex is not None:
                rep.write("**Taxa de sobrevivência por sexo**:\n\n")
                rep.write(by_sex.to_markdown(index=False) + "\n\n")
            if by_pclass is not None:
                rep.write("**Taxa de sobrevivência por classe**:\n\n")
                rep.write(by_pclass.to_markdown(index=False) + "\n\n")
            if by_embarked is not None:
                rep.write("**Taxa de sobrevivência por porto de embarque**:\n\n")
                rep.write(by_embarked.to_markdown(index=False) + "\n\n")

    log("Concluído. Verifique a pasta 'reports' para o arquivo insights.md e 'outputs/figs' para os gráficos.")

def main():
    parser = argparse.ArgumentParser(description="AED do Titanic: importação, preparação e visualização")
    parser.add_argument("--csv", type=str, default=None, help="Caminho opcional para o CSV do Titanic")
    parser.add_argument("--cenarios", type=str, default="basico,imputacao,drop_ausentes", help="Lista separada por vírgula: basico,imputacao,drop_ausentes")
    args = parser.parse_args()

    scenario_keys = [k.strip() for k in args.cenarios.split(',') if k.strip()]
    run_all(args.csv, scenario_keys)

if __name__ == "__main__":
    main()
