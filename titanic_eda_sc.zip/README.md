
# AED do Titanic — Santa Catarina (SC)

Este projeto atende à atividade prática de Análise Exploratória de Dados (AED) usando a base pública do Titanic (CSV). O objetivo é importar, organizar e analisar o conjunto de dados, explorar padrões e fatores associados à sobrevivência, e documentar insights.

## Estrutura do projeto

```
titanic_eda_sc/
├─ data/
│  ├─ raw/                # Coloque aqui o CSV do Titanic (ex.: titanic.csv)
│  └─ processed/          # Saída com datasets limpos por cenário
├─ outputs/
│  └─ figs/               # Gráficos gerados
├─ reports/
│  └─ insights.md         # Compilado de insights gerado pelo script
├─ src/
│  ├─ eda_titanic.py      # Funções de EDA e métricas
│  ├─ scenarios.py        # Definição de cenários e regras de tratamento
│  ├─ visualize.py        # Funções de visualização (matplotlib)
│  └─ utils.py            # Utilitários (paths, download opcional, etc.)
├─ main.py                # Ponto de entrada (CLI)
└─ requirements.txt       # Dependências mínimas
```

## Como obter o dataset

- Você pode baixar manualmente o arquivo CSV a partir do link fornecido no enunciado da atividade (Google Drive).
- Alternativamente, o script tenta baixar automaticamente de: `https://drive.google.com/file/d/11HptTxJbUMRG16xpC39fcliba_-Z_J9d/` (usa `gdown`, opcional). Caso a rede/autenticação impeça, coloque o CSV manualmente em `data/raw/`.

## Instalação

**Requisitos**: Python 3.10+ recomendado.

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scriptsctivate
pip install -r requirements.txt
```

> Dica: Se não quiser instalar `gdown`, você pode ignorar o download automático e colocar o CSV manualmente em `data/raw/`.

## Execução

Execute todos os cenários (básico, imputação e remoção de ausentes):

```bash
python main.py
```

Ou especifique o caminho do CSV e cenários desejados:

```bash
python main.py --csv data/raw/titanic.csv --cenarios basico,imputacao
```

**Saídas geradas**:

- `reports/insights.md` — compilado com estatísticas e taxas de sobrevivência por grupos.
- `outputs/figs/` — pelo menos três gráficos: 
  - Distribuição de Idade por Sobrevivência
  - Taxa de Sobrevivência por Sexo
  - Taxa de Sobrevivência por Classe
- `data/processed/` — versões limpas do dataset por cenário (`titanic_basico.csv`, `titanic_imputacao.csv`, `titanic_drop_ausentes.csv`).

## O que os cenários fazem (regras)

- **basico**: Remove duplicados, ajusta tipos (categorias e numéricos) e cria variáveis derivadas (`FamilySize`, `IsAlone`, `Title`).
- **imputacao**: Tudo do básico + imputação de `Age` (mediana por sexo e classe), `Fare` (mediana), `Embarked` (modo) e `Cabin` (`Desconhecida`).
- **drop_ausentes**: Tudo do básico + exclusão de linhas com ausentes em (`Age`, `Embarked`, `Fare`).

## Documentação e entrega

- Inclua o arquivo `reports/insights.md` e os gráficos (`outputs/figs/`) na pasta compactada de entrega, junto com o `data/processed/` e o `README.md`.
- Certifique-se de adicionar à pasta `data/raw/` o CSV utilizado. 

## Observação

Este repositório **não** inclui o dataset por padrão. O código foi preparado para funcionar assim que o CSV estiver presente em `data/raw/`.

